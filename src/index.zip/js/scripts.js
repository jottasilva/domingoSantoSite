export default function promoters(){
    window.location.href="/promoters";
}