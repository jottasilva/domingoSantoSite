import {BotaoWppPromoter,Pdados, IconRedes,BotaoInstaPromoter, PromoterDados, PromoterFoto, PromotersPageTitulo, PromotersPg, PromotersPromote } from "./components/component";
import iconIWapp from "./imgs/icons/whatsapp.svg";
import iconInsta from "./imgs/icons/instagram.svg";
import { Link } from "react-router-dom";
function PromotersPage(){
    const dadosPromoters = [
        {
            nome : "Jurisberto Gonçalvez Cunha",
            cidade : "Jacarezinho-pr",
            foto : "http://editoraunesp.com.br/blog/icone/confira-o-conceito-de-esfera-publica-de-acordo-com-giddens-e-sutton-",
            instagram : "http://instagram.com/@jurisbertogonz",
            whatsapp: "https://api.whatsapp.com/send?phone=5543991359790&text=Ol%C3%A1,%20Vim%20pedo%20Site%20do%20Domingo%20santo!"
        },
        {
            nome : "Juliana Maria de Souza IA",
            cidade : "Jacarezinho-pr",
            foto : "https://conteudo.imguol.com.br/c/noticias/62/2023/04/13/imagem-de-claudia-foi-gerada-a-partir-de-descricao-simples-em-ferramenta-de-ia-1681400857164_v2_900x506.jpg",
            instagram : "http://instagram.com/@juliana IA",
            whatsapp: "https://api.whatsapp.com/send?phone=5543991359790&text=Ol%C3%A1,%20Vim%20pedo%20Site%20do%20Domingo%20santo!"
        }
    ];
 
    return(
        
        <PromotersPg>
            <Link style={{textDecoration:'none',color:'#fff'}} to="/">
            <h1 style={{marginTop:'20px'}}>Voltar</h1>
            </Link>
            <PromotersPageTitulo/>
            {
                dadosPromoters.map((prm) => (                          
                    <PromotersPromote>
                        <PromoterFoto style={{backgroundImage:`url(${prm.foto})`, backgroundSize:'cover',backgroundPosition:'center'}}/>                         
                        <PromoterDados id="promoterdados">
                        <h2>{prm.nome}</h2>
                        <span>● {prm.cidade}</span>
                            <Pdados>
                                <BotaoWppPromoter onClick={() => window.location.href=prm.whatsapp} id="botoesPromoter">
                                    <IconRedes> 
                                    <img width={30} src={iconIWapp}  alt="Icone Contato Whatsapp" />
                                    </IconRedes>
                                        <section>
                                        <h3>COMPRE AGORA</h3>
                                        </section>
                                    </BotaoWppPromoter>
                                    <BotaoInstaPromoter onClick={() => window.location.href=prm.instagram} id="botoesPromoter">
                                    <IconRedes> 
                                    <img width={30} src={iconInsta}  alt="Icone Contato Instagram" />
                                    </IconRedes>
                                        <section>
                                        <h3>ME SIGA!</h3>
                                        </section>
                                    </BotaoInstaPromoter>
                            </Pdados>
                </PromoterDados>
                
            </PromotersPromote>
                ))
            }
        </PromotersPg>  

    );
}
export default PromotersPage;